#include <boost/program_options.hpp>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/common/point_operators.h>
#include <pcl/common/io.h>
#include <pcl/search/organized.h>
#include <pcl/search/octree.h>
#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/filters/conditional_removal.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/surface/gp3.h>
#include <pcl/io/vtk_io.h>
#include <pcl/filters/voxel_grid.h>

#include <iostream>
#include <fstream>

using namespace pcl;
using namespace std;

namespace po = boost::program_options;

int main(int argc, char **argv) {
    //********************bin2pcd*********************
    /*
     * i=1; for x in /home/wenyan/Documents/MasterThesis/mymt_ws/dataset/in_0002_sync/*.bin;
     * do /home/wenyan/Documents/MasterThesis/mymt_ws/build/read_data --infile
     * $x --outfile /home/wenyan/Documents/MasterThesis/mymt_ws/dataset/out_0002_sync/$i.pcd; let i=i+1; done
     */

    string infile;
    string outfile;

    // Declare the supported options.
    //选项描述器:	当前程序定义了哪些选项,参数为该描述器的名字
    po::options_description desc("Program options");
    po::variables_map vm; //选项存储器:容器,用于存储解析后的选项

    //params: key, type of value, description
    desc.add_options()
            //Options
            ("infile", po::value<string>(&infile)->required(), "the file to read a point cloud from")
            ("outfile", po::value<string>(&outfile)->required(), "the file to write the DoN point cloud & normals to");
    // Parse the command line

    try{
        //parse_command_line(): 选项分析器,解析由命令行输入的参数
        //store() 将解析后的结果存入选项存储器
        po::store(po::parse_command_line(argc, argv, desc), vm);
    }
    catch(...){
        cout<<"Error: input some undefined params.\n";
        return 0;
    }

    if (vm.count("help")) {
        cout << desc << "\n";
        return false;
    }


    // Process options.
    //通知variables_map去更新所有外部变量
    po::notify(vm);

    // load point cloud
    fstream input(infile.c_str(), ios::in | ios::binary);
    if (!input.good()) {
        cerr << "Could not read file: " << infile << endl;
        exit(EXIT_FAILURE);
    }
    input.seekg(0, ios::beg);

    pcl::PointCloud<PointXYZI>::Ptr points(new pcl::PointCloud <PointXYZI>);

    int i;
    for (i = 0; input.good() && !input.eof(); i++) {
        PointXYZI point;
        input.read((char *) &point.x, 3 * sizeof(float));
        input.read((char *) &point.intensity, sizeof(float));
        points->push_back(point);
    }
    input.close();

    cout << "Read KITTI point cloud with " << i << " points, writing to " << outfile << endl;

    pcl::PCDWriter writer;
    writer.write<PointXYZI>(outfile, *points, false);
}