#include "pointcloud.h"

void PointCloud::view_pcdxyz(PointCloudTI::Ptr cloud, const std::string& window_name) {
    pcl::visualization::PCLVisualizer viewer(window_name);
    pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_color(cloud, 0, 0,255);
    viewer.addPointCloud(cloud, cloud_color);
    viewer.setBackgroundColor(255,255,255);
    while (!viewer.wasStopped())
    {
        viewer.spinOnce(50);
    }
    return 0;
}

void PointCloud::view_pcdxyzi(PointCloudTI::Ptr cloud, const std::string& window_name) {
    boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer(new pcl::visualization::PCLVisualizer(window_name));
    pcl::visualization::PointCloudColorHandlerGenericField<PointTI> point_cloud_color_handler(cloud, "intensity");
    viewer->addPointCloud<PointTI>(cloud, point_cloud_color_handler, "id");
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "id");
    viewer->setBackgroundColor(255,255,255);
    //viewer->registerKeyboardCallback(keyboardEventOccurred, (void*)viewer.get());

    while (!viewer->wasStopped()){
        viewer->spinOnce(50);
    }

    viewer->close();
}

