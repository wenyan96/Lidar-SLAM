#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/visualization/cloud_viewer.h>
#include <sstream>


typedef pcl::PointXYZ PointT;


int main(int argc, char **argv) {
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>); // Create a point cloud (pointer)
    std::stringstream ss;

    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/wenyan/Documents/MasterThesis/mymt_ws/dataset/out_0002_sync/1.pcd", *cloud) == -1) //* Read the file in PCD format, if File does not exist, return -1
    {
        PCL_ERROR ("Couldn't read file test_pcd.pcd \n"); // When the file does not exist, return an error, terminate the program.
        return (-1);
    }

    pcl::visualization::PCLVisualizer viewer("Point Cloud Viewer");
    //pcl::visualization::CloudViewer viewer("Point Cloud Viewer");//Create a display window directly
    pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_color(cloud, 0, 0,255);
    viewer.addPointCloud(cloud, cloud_color);
    viewer.setBackgroundColor(255,255,255);
    viewer.addCoordinateSystem (3.0);
    //viewer.showCloud(cloud);//Show point cloud in this window
    while (!viewer.wasStopped())
    {
       viewer.spinOnce(50);
    }
    //viewer->close();
    return 0;
}
