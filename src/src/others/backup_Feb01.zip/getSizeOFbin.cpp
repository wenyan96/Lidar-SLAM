
// 完整C++代码
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main(){
    float data[6];
    string filename = "/home/wenyan/Documents/MasterThesis/mymt_ws/dataset/in_0002_sync/1.bin";
    ifstream fs;
    fs.open(filename, ios_base::binary | ios_base::in);
    fs.read(reinterpret_cast<char*>(data), sizeof(float)* 6);
    fs.close();
    for (int i = 0; i < 6; i++){
        cout << data[i] << endl;
    }
    return 0;
}