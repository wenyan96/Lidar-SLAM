#include <iostream>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <opencv4/opencv2/core/core.hpp>
#include <pcl/io/pcd_io.h>

typedef pcl::PointXYZ PointT;
typedef pcl::PointCloud<PointT> PointCloudT;
typedef pcl::PointXYZI PointTI;
typedef pcl::PointCloud<PointTI> PointCloudTI;



void xyz2xyzi(PointCloudT cloudin, PointCloudTI& cloudout){

    cloudout.width    = cloudin.width ;
    cloudout.height   = cloudin.height;
    cloudout.is_dense = cloudin.is_dense;
    cloudout.points.resize(cloudin.width * cloudin.height);
    for (int i=0; i<cloudin.points.size(); i++){
        cloudout.points[i].x = cloudin.points[i].x;
        cloudout.points[i].y = cloudin.points[i].y;
        cloudout.points[i].z = cloudin.points[i].z;
        cloudout.points[i].intensity = 0;
    }
}

int main (int argc, char** argv)
{

    PointCloudT::Ptr cloud(new PointCloudT);
    PointCloudTI::Ptr cloud_i(new PointCloudTI);
    PointCloudT::Ptr cloud_filtered(new PointCloudT);
    PointCloudT::Ptr cloud_filtered2(new PointCloudT);

    // 读入点云PCD文件
    std::string cloud_path = "/home/wenyan/Documents/MasterThesis/mymt_ws/dataset/out_0002_sync/1.pcd";
    pcl::io::loadPCDFile<PointT>(cloud_path, *cloud);
    std::cerr << "Point cloud data: " << cloud->points.size () << " points" << std::endl;
    pcl::visualization::PCLVisualizer viewer0("Point Cloud Viewer: original");
    pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_color(cloud, 0, 0,205);
    viewer0.addPointCloud(cloud, cloud_color);
    viewer0.setBackgroundColor(255,255,255);
    while (!viewer0.wasStopped())
    {
        viewer0.spinOnce(50);
    }

    std::vector<int> indices;
    pcl::removeNaNFromPointCloud(*cloud, *cloud, indices);
    std::cerr << "Cloud after NaN removal: " << cloud->points.size () << " points" << std::endl;
    // 点云可视化
    //viewer.runOnVisualizationThreadOnce(viewerOneOff);
    pcl::visualization::PCLVisualizer viewer1("Point Cloud Viewer: ground removal");
    //pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_color(cloud, 0, 0,205);
    viewer0.addPointCloud(cloud, cloud_color);
    viewer0.setBackgroundColor(255,255,255);
    while (!viewer0.wasStopped())
    {
        viewer0.spinOnce(50);
    }

    pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
    pcl::PointIndices::Ptr inliers (new pcl::PointIndices);
    // Create the segmentation object
    pcl::SACSegmentation<pcl::PointXYZ> seg;
    seg.setOptimizeCoefficients (true);
    seg.setModelType (pcl::SACMODEL_PLANE);
    seg.setMethodType (pcl::SAC_RANSAC);
    // 距离阈值 单位m
    seg.setDistanceThreshold (0.45);
    seg.setInputCloud (cloud);
    seg.segment (*inliers, *coefficients);
    if (inliers->indices.size () == 0)
    {
        PCL_ERROR ("Could not estimate a planar model for the given dataset.");
        return (-1);
    }

    // 提取地面
    pcl::ExtractIndices<pcl::PointXYZ> extract;
    extract.setInputCloud(cloud);
    extract.setIndices(inliers);
    extract.filter(*cloud_filtered);
    std::cerr << "Ground cloud after filtering: " << std::endl;
    std::cerr << *cloud_filtered << std::endl;


    // 提取除地面外的物体
    extract.setNegative (true); //如果为true,提取指定index之外的点云
    extract.filter(*cloud_filtered);

    std::cerr << "Object cloud after filtering: " << std::endl;
    std::cerr << *cloud_filtered << std::endl;

    // 点云可视化
    //viewer.runOnVisualizationThreadOnce(viewerOneOff);
    pcl::visualization::PCLVisualizer viewer("Point Cloud Viewer: ground removal");
    //pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_color(cloud_filtered, 0, 0,205);
    viewer.addPointCloud(cloud_filtered, cloud_color);
    viewer.setBackgroundColor(255,255,255);

    pcl::io::savePCDFileASCII<PointT>("ground_remove.pcd", *cloud); //默认二进制方式保存
    //pcl::io::savePCDFileBinary<pcl::PointXYZ>("ground_remove_b.bin", *cloud); //二进制方式保存

    while (!viewer.wasStopped())
    {
        viewer.spinOnce(50);
    }


    pcl::RadiusOutlierRemoval<pcl::PointXYZ> outremov;
    outremov.setInputCloud(cloud_filtered);
    outremov.setRadiusSearch(0.3);
    outremov.setMinNeighborsInRadius(5);
    outremov.filter(*cloud_filtered2);


    pcl::visualization::PCLVisualizer viewer2("Point Cloud Viewer: noise removal");
    pcl::visualization::PointCloudColorHandlerCustom<PointT> cloud_color2(cloud_filtered, 0, 0,185);
    viewer2.addPointCloud(cloud_filtered2, cloud_color2);
    viewer2.setBackgroundColor(255,255,255);
    while (!viewer2.wasStopped())
    {
        viewer2.spinOnce(50);
    }

    std::cerr << "Object cloud after noise filtering: " << std::endl;
    std::cerr << *cloud_filtered2 << std::endl;

    xyz2xyzi(*cloud_filtered2, *cloud_i);
    pcl::io::savePCDFileASCII<PointTI>("ground_i.pcd", *cloud_i); //默认二进制方式保存


    return 0;
}